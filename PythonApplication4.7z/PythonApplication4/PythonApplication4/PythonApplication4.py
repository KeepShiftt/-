fio = "Гарри,Гермиона,Рон"
user_name = input("Ваше имя: \n")
if user_name in fio:
    print("Есть в базе данных")
else:
    print("Нет в базе данных")
