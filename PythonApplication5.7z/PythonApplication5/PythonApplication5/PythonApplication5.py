print(4*4*4)
